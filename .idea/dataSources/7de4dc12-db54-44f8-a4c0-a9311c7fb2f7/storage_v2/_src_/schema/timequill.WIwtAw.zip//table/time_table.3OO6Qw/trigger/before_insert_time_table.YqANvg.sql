create definer = hedgehog@localhost trigger before_insert_time_table
    before insert
    on time_table
    for each row
BEGIN
    SET NEW.worked_hours = TIMESTAMPDIFF(SECOND, CONCAT(CURDATE(), ' ', NEW.start_time), CONCAT(CURDATE(), ' ', NEW.end_time)) / 3600;
END;

